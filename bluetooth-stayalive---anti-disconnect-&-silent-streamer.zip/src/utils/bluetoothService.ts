import { BluetoothDeviceInfo } from '../types';

const STORAGE_KEY_DEVICES = 'bt_stayalive_devices_history';
const STORAGE_KEY_LOCKED_DEVICE = 'bt_stayalive_locked_device_id';

export class BluetoothService {
  public static isWebBluetoothSupported(): boolean {
    return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
  }

  public static getSavedDevices(): BluetoothDeviceInfo[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_DEVICES);
      if (raw) {
        return JSON.parse(raw);
      }
    } catch {
      // Storage unavailable
    }
    return [];
  }

  public static saveDevices(devices: BluetoothDeviceInfo[]) {
    try {
      localStorage.setItem(STORAGE_KEY_DEVICES, JSON.stringify(devices));
    } catch {
      // Storage full or unavailable
    }
  }

  public static getLockedDeviceId(): string | null {
    return localStorage.getItem(STORAGE_KEY_LOCKED_DEVICE) || null;
  }

  public static setLockedDeviceId(id: string | null) {
    if (id) {
      localStorage.setItem(STORAGE_KEY_LOCKED_DEVICE, id);
    } else {
      localStorage.removeItem(STORAGE_KEY_LOCKED_DEVICE);
    }
  }

  /**
   * Scan for real Bluetooth devices using the Web Bluetooth API
   */
  public static async scanRealDevice(): Promise<BluetoothDeviceInfo | null> {
    if (!this.isWebBluetoothSupported()) {
      throw new Error('WEB_BLUETOOTH_UNSUPPORTED');
    }

    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const navBt = (navigator as any).bluetooth;
      const device = await navBt.requestDevice({
        acceptAllDevices: true,
        optionalServices: ['battery_service', 0x180F],
      });

      let batteryLevel: number | null = null;
      try {
        if (device.gatt) {
          const server = await device.gatt.connect();
          const service = await server.getPrimaryService('battery_service');
          const char = await service.getCharacteristic('battery_level');
          const val = await char.readValue();
          batteryLevel = val.getUint8(0);
        }
      } catch {
        // Battery service might not be exposed by some headsets or proprietary GATT
        batteryLevel = null;
      }

      const newDevice: BluetoothDeviceInfo = {
        id: device.id || `bt-${Date.now()}`,
        name: device.name || 'Bluetooth Headset',
        connected: true,
        batteryLevel: batteryLevel,
        rssi: -58,
        lastSeen: 'همین الان',
        macAddress: device.id ? device.id.slice(0, 17) : 'BLE_CONNECTED',
        isLocked: true,
      };

      const existing = this.getSavedDevices().filter(d => d.id !== newDevice.id);
      this.saveDevices([newDevice, ...existing]);
      this.setLockedDeviceId(newDevice.id);

      return newDevice;
    } catch (err) {
      const errorStr = String(err);
      if (errorStr.includes('User cancelled')) {
        return null;
      }
      throw err;
    }
  }
}
