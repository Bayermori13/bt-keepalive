import React, { useState, useEffect } from 'react';
import {
  Power,
  Volume2,
  VolumeX,
  Radio,
  CheckCircle2,
  ShieldCheck,
  Cpu,
  Layers,
} from 'lucide-react';
import { KeepAliveMode, Language, ActivityEvent } from '../types';
import { audioEngine } from '../utils/audioEngine';

interface KeepAliveControllerProps {
  language: Language;
  onAddLog: (event: Omit<ActivityEvent, 'id' | 'timestamp'>) => void;
  isActive: boolean;
  onToggleActive: () => void;
}

export const KeepAliveController: React.FC<KeepAliveControllerProps> = ({
  language,
  onAddLog,
  isActive,
  onToggleActive,
}) => {
  const isFa = language === 'fa';
  const [mode, setMode] = useState<KeepAliveMode>('pure_silence');
  const [uptimeSeconds, setUptimeSeconds] = useState<number>(0);

  // Uptime timer
  useEffect(() => {
    let timer: number;
    if (isActive) {
      timer = window.setInterval(() => {
        setUptimeSeconds(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isActive]);

  const handleModeChange = (newMode: KeepAliveMode) => {
    setMode(newMode);
    if (isActive) {
      audioEngine.start(newMode);
      onAddLog({
        type: 'keepalive',
        title: isFa ? 'تغییر متد سکوت دائمی' : 'Non-Stop Mode Changed',
        detail: isFa
          ? `پخش دائم بدون توقف با متد ${getModeLabel(newMode)} فعال است.`
          : `Continuous keep-alive set to ${newMode}.`,
      });
    }
  };

  const formatUptime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getModeLabel = (m: KeepAliveMode) => {
    if (m === 'pure_silence') return isFa ? 'سکوت مطلق (دیجیتال 0dB)' : 'Pure Digital Zero (0 dB)';
    if (m === 'sub_bass') return isFa ? 'فرکانس نامحسوس (۱۵ هرتز)' : 'Inaudible Sub-Bass (15 Hz)';
    return isFa ? 'تک‌پالس دوره‌ای (هر ۳ ثانیه)' : 'Periodic Burst (Every 3s)';
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Non-Stop Policy Banner */}
      <div className="rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 p-4 sm:p-5 shadow-lg">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
              <span className="text-xs sm:text-sm font-bold text-white">
                {isFa ? 'استریم پیوسته و دائمی سکوت (آماده استفاده عملیاتی)' : 'Production Non-Stop Silence Streamer'}
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 leading-relaxed max-w-2xl">
              {isFa
                ? 'پخش مداوم سکوت صفر دیجیتال با حداقل مصرف انرژی و بیدار نگه‌داشتن همیشگی لینک A2DP بدون هیچ‌گونه تداخل با تماس‌های صوتی یا پخش موزیک.'
                : 'Continuous digital zero PCM streaming keeps A2DP audio sink and DAC awake 24/7 without audio conflict.'}
            </p>
          </div>

          <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end shrink-0">
            <div className={`px-2.5 py-1 rounded-lg text-[11px] font-mono border ${
              isActive
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                : 'bg-slate-900 text-slate-500 border-slate-800'
            }`}>
              {isActive
                ? (isFa ? 'سرویس فعال و بیدار' : 'Stream Active')
                : (isFa ? 'سرویس خاموش' : 'Service Inactive')}
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Left = Power Switch & Visualizer, Right = Signal Mode & Pipeline Specs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6">
        {/* Left Column (7 cols): Tactile Power Switch & Frequency Wave */}
        <div className="lg:col-span-7 rounded-2xl border border-slate-800 bg-slate-900/60 p-4 sm:p-6 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {isFa ? 'کلید اصلی پخش دائم سکوت' : 'Non-Stop Silence Switch'}
                </h2>
                <p className="text-[11px] sm:text-xs text-slate-400">
                  {isFa ? 'روشن/خاموش کردن سرویس بیدار نگه‌داشتن هندزفری' : 'Toggle 24/7 headset keep-alive service'}
                </p>
              </div>
              <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
                <span>{isFa ? 'مدت کارکرد:' : 'Uptime:'}</span>
                <span className="font-bold text-cyan-400 tabular-nums">{formatUptime(uptimeSeconds)}</span>
              </div>
            </div>

            {/* Big Tactile Center Switch */}
            <div className="my-6 sm:my-8 flex flex-col items-center justify-center">
              <button
                onClick={onToggleActive}
                className={`relative flex h-32 w-32 sm:h-40 sm:w-40 items-center justify-center rounded-full transition-all duration-300 active:scale-95 shadow-xl ${
                  isActive
                    ? 'bg-gradient-to-tr from-cyan-500 to-emerald-400 text-slate-950 shadow-cyan-500/30 ring-4 sm:ring-8 ring-cyan-500/20'
                    : 'bg-slate-800 hover:bg-slate-750 text-slate-400 border border-slate-700 shadow-slate-950/60'
                }`}
                aria-label={isActive ? 'خاموش کردن سرویس' : 'روشن کردن سرویس'}
              >
                <div className="flex flex-col items-center">
                  <Power className={`h-10 w-10 sm:h-14 sm:w-14 transition-transform ${isActive ? 'scale-105 text-slate-950' : 'text-slate-400'}`} />
                  <span className="mt-1 sm:mt-2 text-[11px] sm:text-xs font-bold tracking-tight">
                    {isActive
                      ? isFa ? 'روشن (در حال پخش)' : 'ACTIVE'
                      : isFa ? 'روشن کردن' : 'START'}
                  </span>
                </div>
              </button>

              <p className="mt-3 text-[11px] sm:text-xs text-slate-400 text-center max-w-xs">
                {isActive
                  ? isFa
                    ? 'استریم سکوت فعال است. هندزفری بلوتوث بعد از قطع تماس یا آهنگ خاموش نمی‌شود.'
                    : 'A2DP audio link is locked 24/7. Headset DAC will never enter sleep mode.'
                  : isFa
                    ? 'برای فعال‌سازی جریان سکوت و جلوگیری از قطع شدن هندزفری، کلید بالا را روشن کنید.'
                    : 'Tap the button to start the continuous non-stop silent stream.'}
              </p>
            </div>
          </div>

          {/* Soundwave Frequency Monitor */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-3 sm:p-4">
            <div className="flex items-center justify-between text-xs mb-2.5">
              <div className="flex items-center gap-1.5">
                <Radio className={`h-3.5 w-3.5 ${isActive ? 'text-cyan-400 animate-pulse' : 'text-slate-600'}`} />
                <span className="font-medium text-slate-300 text-[11px] sm:text-xs">
                  {isFa ? 'مانیتور لحظه‌ای خروجی صوتی (Audio Output)' : 'Live Audio Output Monitor'}
                </span>
              </div>
              <span className="font-mono text-[10px] sm:text-[11px] text-slate-500">
                {isActive ? '44.1 kHz · Zero PCM' : 'Idle'}
              </span>
            </div>

            {/* Soundwave Bars */}
            <div className="flex h-10 items-end justify-between gap-1 px-1">
              {[30, 50, 35, 70, 45, 80, 40, 65, 55, 85, 35, 60, 50, 75, 25, 55, 45, 70, 30, 50, 40, 75].map((val, idx) => (
                <div
                  key={idx}
                  className={`flex-1 rounded-t transition-all duration-150 ${
                    isActive
                      ? 'bg-gradient-to-t from-cyan-500 to-emerald-400'
                      : 'bg-slate-800 h-1.5'
                  }`}
                  style={{
                    height: isActive
                      ? `${Math.max(12, val * (0.6 + (idx % 3) * 0.2))}%`
                      : '8%',
                  }}
                />
              ))}
            </div>

            <div className="mt-2 flex items-center justify-between text-[10px] font-mono text-slate-500 border-t border-slate-850 pt-1.5">
              <span>0 Hz (Digital Zero)</span>
              <span>15 Hz Sub-Bass</span>
              <span>Continuous Output</span>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Signal Mode Selector & Technical Diagnostics */}
        <div className="lg:col-span-5 space-y-4 sm:space-y-6">
          {/* Mode Selector */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 sm:p-5">
            <h3 className="text-xs sm:text-sm font-bold text-white mb-0.5">
              {isFa ? 'نوع سیگنال سکوت دائم' : 'Continuous Silence Type'}
            </h3>
            <p className="text-[11px] text-slate-400 mb-3">
              {isFa ? 'سیگنال بدون توقف برای بیدار نگه داشتن چیپست هندزفری' : 'Select silent synthesis for your Bluetooth chip'}
            </p>

            <div className="space-y-2">
              {/* Pure silence */}
              <button
                onClick={() => handleModeChange('pure_silence')}
                className={`w-full flex items-start gap-2.5 p-2.5 sm:p-3 rounded-xl border text-right transition-all ${
                  mode === 'pure_silence'
                    ? 'border-cyan-500/50 bg-cyan-950/20 text-white'
                    : 'border-slate-800 hover:border-slate-750 bg-slate-900 text-slate-300'
                }`}
              >
                <div className={`mt-0.5 rounded-lg p-1.5 ${mode === 'pure_silence' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
                  <VolumeX className="h-3.5 w-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">
                      {isFa ? 'سکوت مطلق (دیجیتال 0dB)' : 'Pure Digital Zero (0 dB)'}
                    </span>
                    <span className="text-[10px] font-mono text-cyan-400">پیش‌فرض</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                    {isFa
                      ? 'بافر کاملاً خالی بدون کوچکترین وزوز؛ سازگار با تمام تماس‌ها و موزیک‌ها.'
                      : 'Continuous zeros buffer; absolute zero noise, ideal for calls.'}
                  </p>
                </div>
              </button>

              {/* Sub-bass */}
              <button
                onClick={() => handleModeChange('sub_bass')}
                className={`w-full flex items-start gap-2.5 p-2.5 sm:p-3 rounded-xl border text-right transition-all ${
                  mode === 'sub_bass'
                    ? 'border-cyan-500/50 bg-cyan-950/20 text-white'
                    : 'border-slate-800 hover:border-slate-750 bg-slate-900 text-slate-300'
                }`}
              >
                <div className={`mt-0.5 rounded-lg p-1.5 ${mode === 'sub_bass' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
                  <Volume2 className="h-3.5 w-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">
                      {isFa ? 'فرکانس نامحسوس (۱۵ هرتز)' : 'Inaudible Sub-Bass (15 Hz)'}
                    </span>
                    <span className="text-[10px] font-mono text-cyan-400">&lt; 20Hz</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                    {isFa
                      ? 'مخصوص هندزفری‌هایی که بعد از تماس فوراً تایم‌اوت می‌دهند.'
                      : 'Stimulates DAC to bypass aggressive sleep timers.'}
                  </p>
                </div>
              </button>

              {/* Periodic Ping */}
              <button
                onClick={() => handleModeChange('periodic_ping')}
                className={`w-full flex items-start gap-2.5 p-2.5 sm:p-3 rounded-xl border text-right transition-all ${
                  mode === 'periodic_ping'
                    ? 'border-cyan-500/50 bg-cyan-950/20 text-white'
                    : 'border-slate-800 hover:border-slate-750 bg-slate-900 text-slate-300'
                }`}
              >
                <div className={`mt-0.5 rounded-lg p-1.5 ${mode === 'periodic_ping' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
                  <Radio className="h-3.5 w-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">
                      {isFa ? 'تک‌پالس بی‌صدا (هر ۳ ثانیه)' : 'Periodic Burst (Every 3s)'}
                    </span>
                    <span className="text-[10px] font-mono text-cyan-400">3s Ping</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                    {isFa
                      ? 'پالس دوره‌ای بدون صدا با حداقل مصرف باتری گوشی و هندزفری.'
                      : 'Micro heartbeats every 3s to reset timeout.'}
                  </p>
                </div>
              </button>
            </div>
          </div>

          {/* Technical Architecture & Specs Card */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 sm:p-5 space-y-3">
            <div className="flex items-center gap-1.5">
              <Cpu className="h-4 w-4 text-cyan-400" />
              <h3 className="text-xs sm:text-sm font-bold text-white">
                {isFa ? 'مشخصات فنی استریم و بدون تداخل' : 'Technical Specifications'}
              </h3>
            </div>

            <div className="space-y-2 text-[11px]">
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-850">
                <span className="text-slate-400">{isFa ? 'پروتکل صوتی:' : 'Audio Sink:'}</span>
                <span className="font-mono text-cyan-300 font-semibold">Bluetooth A2DP (Continuous)</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-850">
                <span className="text-slate-400">{isFa ? 'رمزگذاری بافر:' : 'Buffer Format:'}</span>
                <span className="font-mono text-slate-200">16-bit Linear PCM (44.1 kHz)</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-850">
                <span className="text-slate-400">{isFa ? 'تداخل با مکالمه/موزیک:' : 'Interference Level:'}</span>
                <span className="font-mono text-emerald-400 font-semibold">0% (Zero Invariance)</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-850">
                <span className="text-slate-400">{isFa ? 'وضعیت فورگراند اندروید:' : 'Android Service:'}</span>
                <span className="font-mono text-slate-200">Foreground Media Playback</span>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-950/85 border border-slate-800 flex items-start gap-2 text-[11px] text-slate-400">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                {isFa
                  ? 'بافر دیجیتال صفر مانند یک کانال حامل پیوسته عمل می‌کند و اتصال به هندزفری را بدون اشغال پنهای باند صوتی فعال نگه می‌دارد.'
                  : 'Digital zero PCM maintains active buffer packets to the Bluetooth DAC without audible sound or packet delay.'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
