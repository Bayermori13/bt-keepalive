import React, { useState } from 'react';
import {
  Activity,
  Trash2,
  PhoneCall,
  Volume2,
  Bluetooth,
  Battery,
  ShieldAlert,
  ShieldCheck,
  Wifi,
} from 'lucide-react';
import { ActivityEvent, Language } from '../types';

interface ActivityLogProps {
  language: Language;
  events: ActivityEvent[];
  onClearLogs: () => void;
  onAddLog?: (event: Omit<ActivityEvent, 'id' | 'timestamp'>) => void;
}

export const ActivityLog: React.FC<ActivityLogProps> = ({
  language,
  events,
  onClearLogs,
}) => {
  const isFa = language === 'fa';
  const [filter, setFilter] = useState<'all' | 'prevented' | 'disconnect' | 'media'>('all');

  const filteredEvents = events.filter(e => {
    if (filter === 'prevented') return e.type === 'prevented_disconnect' || e.preventedDisconnect;
    if (filter === 'disconnect') return e.type === 'disconnect' || e.type === 'signal_drop';
    if (filter === 'media') return e.type === 'concurrent_media';
    return true;
  });

  const getEventBadge = (event: ActivityEvent) => {
    if (event.preventedDisconnect || event.type === 'prevented_disconnect') {
      return (
        <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-1.5 py-0.5 rounded">
          <ShieldCheck className="h-3 w-3" />
          <span>{isFa ? 'نجات از خاموشی' : 'Sleep Prevented'}</span>
        </span>
      );
    }
    if (event.type === 'disconnect') {
      return (
        <span className="flex items-center gap-1 text-[10px] font-bold text-rose-400 bg-rose-950/60 border border-rose-500/30 px-1.5 py-0.5 rounded">
          <ShieldAlert className="h-3 w-3" />
          <span>{isFa ? 'قطع ارتباط' : 'Disconnected'}</span>
        </span>
      );
    }
    if (event.type === 'concurrent_media') {
      return (
        <span className="flex items-center gap-1 text-[10px] font-bold text-purple-400 bg-purple-950/60 border border-purple-500/30 px-1.5 py-0.5 rounded">
          <Volume2 className="h-3 w-3" />
          <span>{isFa ? 'میکس هم‌زمان' : 'Concurrent Mix'}</span>
        </span>
      );
    }
    return null;
  };

  const getEventIcon = (type: ActivityEvent['type']) => {
    switch (type) {
      case 'prevented_disconnect':
        return <ShieldCheck className="h-4 w-4 text-emerald-400" />;
      case 'disconnect':
        return <Bluetooth className="h-4 w-4 text-rose-400" />;
      case 'concurrent_media':
        return <PhoneCall className="h-4 w-4 text-purple-400" />;
      case 'signal_drop':
        return <Wifi className="h-4 w-4 text-amber-400" />;
      case 'connect':
        return <Bluetooth className="h-4 w-4 text-cyan-400" />;
      case 'battery':
        return <Battery className="h-4 w-4 text-cyan-400" />;
      default:
        return <Activity className="h-4 w-4 text-slate-400" />;
    }
  };

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 sm:p-6 space-y-4">
      {/* Header and Filter Tabs */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-cyan-400" />
            <h3 className="text-base sm:text-lg font-bold text-white">
              {isFa ? 'لاگ عملیاتی رویدادها، قدرت سیگنال و دلایل قطعی' : 'Real-Time Telemetry & Disconnect Logs'}
            </h3>
          </div>
          <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5">
            {isFa
              ? 'ثبت لحظه‌ای تغییرات وضعیت، قدرت سیگنال (RSSI) و نجات هندزفری از خاموشی'
              : 'Detailed RSSI tracking, sleep prevention events, and disconnect root-causes'}
          </p>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-between flex-wrap">
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800 text-[11px]">
            <button
              onClick={() => setFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                filter === 'all' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              {isFa ? 'همه' : 'All'}
            </button>
            <button
              onClick={() => setFilter('prevented')}
              className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                filter === 'prevented' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              {isFa ? 'نجات از قطعی' : 'Rescues'}
            </button>
            <button
              onClick={() => setFilter('disconnect')}
              className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                filter === 'disconnect' ? 'bg-rose-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              {isFa ? 'علت قطعی' : 'Drops'}
            </button>
            <button
              onClick={() => setFilter('media')}
              className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                filter === 'media' ? 'bg-purple-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              {isFa ? 'تماس/آهنگ' : 'Calls'}
            </button>
          </div>

          {events.length > 0 && (
            <button
              onClick={onClearLogs}
              className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-400 hover:text-rose-400 rounded-lg border border-slate-800 hover:border-rose-900 transition-colors"
              title={isFa ? 'پاک کردن لاگ‌ها' : 'Clear Log'}
            >
              <Trash2 className="h-3 w-3" />
              <span>{isFa ? 'پاک‌سازی' : 'Clear'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Events List */}
      <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-0.5">
        {filteredEvents.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-500">
            {isFa
              ? 'هنوز رویدادی ثبت نشده است. با اتصال هندزفری و فعال بودن سرویس، گزارش‌ها به طور خودکار ثبت می‌شوند.'
              : 'No activity recorded yet. Events will appear here once the service and device are active.'}
          </div>
        ) : (
          filteredEvents.map(event => (
            <div
              key={event.id}
              className={`p-3 rounded-xl border transition-colors ${
                event.preventedDisconnect
                  ? 'border-emerald-500/30 bg-emerald-950/20 hover:bg-emerald-950/30'
                  : event.type === 'disconnect'
                  ? 'border-rose-500/30 bg-rose-950/20 hover:bg-rose-950/30'
                  : 'border-slate-850 bg-slate-950/60 hover:bg-slate-950'
              }`}
            >
              <div className="flex items-start gap-2.5">
                <div className={`mt-0.5 rounded-lg p-1.5 border shrink-0 ${
                  event.preventedDisconnect
                    ? 'bg-emerald-500/20 border-emerald-500/40'
                    : event.type === 'disconnect'
                    ? 'bg-rose-500/20 border-rose-500/40'
                    : 'bg-slate-900 border-slate-800'
                }`}>
                  {getEventIcon(event.type)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-bold text-white">
                        {event.title}
                      </span>
                      {getEventBadge(event)}
                    </div>

                    <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400 shrink-0">
                      {event.rssi !== undefined && (
                        <span className={`px-1.5 py-0.5 rounded border ${
                          event.rssi >= -65
                            ? 'text-emerald-400 border-emerald-500/30 bg-emerald-950/40'
                            : event.rssi >= -80
                            ? 'text-cyan-400 border-cyan-500/30 bg-cyan-950/40'
                            : 'text-rose-400 border-rose-500/30 bg-rose-950/40'
                        }`}>
                          RSSI: {event.rssi} dBm
                        </span>
                      )}
                      <span>{event.timestamp}</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                    {event.detail}
                  </p>

                  {/* Disconnect Reason Box if present */}
                  {event.disconnectReason && (
                    <div className="mt-2 text-[10px] text-rose-300 font-medium bg-rose-950/40 border border-rose-500/20 px-2 py-1 rounded inline-block">
                      {isFa ? 'دلیل قطع اتصال:' : 'Disconnect Cause:'} {event.disconnectReason}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
