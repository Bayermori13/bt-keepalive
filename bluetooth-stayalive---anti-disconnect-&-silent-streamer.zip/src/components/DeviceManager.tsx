import React, { useState } from 'react';
import {
  Bluetooth,
  Battery,
  BatteryCharging,
  Wifi,
  Lock,
  Unlock,
  RefreshCw,
  Search,
  Clock,
  Radio,
  CheckCircle2,
  Headphones,
} from 'lucide-react';
import { BluetoothDeviceInfo, Language, ActivityEvent } from '../types';
import { BluetoothService } from '../utils/bluetoothService';

interface DeviceManagerProps {
  language: Language;
  devices: BluetoothDeviceInfo[];
  onUpdateDevices: (devices: BluetoothDeviceInfo[]) => void;
  onAddLog: (event: Omit<ActivityEvent, 'id' | 'timestamp'>) => void;
}

export const DeviceManager: React.FC<DeviceManagerProps> = ({
  language,
  devices,
  onUpdateDevices,
  onAddLog,
}) => {
  const isFa = language === 'fa';
  const [isScanning, setIsScanning] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);

  const lockedDevice = devices.find(d => d.isLocked && d.connected) || devices[0];

  const handleScanWebBluetooth = async () => {
    setIsScanning(true);
    setScanError(null);
    try {
      const newDev = await BluetoothService.scanRealDevice();
      if (newDev) {
        onAddLog({
          type: 'connect',
          title: isFa ? 'اتصال به دستگاه بلوتوث' : 'Connected to Bluetooth Device',
          detail: isFa
            ? `دستگاه ${newDev.name} شناسایی و قفل شد. سیگنال: ${newDev.rssi} dBm.`
            : `Device ${newDev.name} discovered and locked (RSSI: ${newDev.rssi} dBm).`,
          rssi: newDev.rssi,
          batteryLevel: newDev.batteryLevel,
        });
        onUpdateDevices(BluetoothService.getSavedDevices());
      }
    } catch (err: unknown) {
      const errStr = String(err);
      if (errStr.includes('WEB_BLUETOOTH_UNSUPPORTED')) {
        setScanError(
          isFa
            ? 'مرورگر فعلی از Web Bluetooth API پشتیبانی نمی‌کند (در گوگل کروم اندروید برای شناسایی زنده بلوتوث استفاده می‌شود). در اپلیکیشن اندروید، دستگاه‌ها از بلوتوث سیستم‌عامل متصل می‌شوند.'
            : 'Web Bluetooth API is supported on Chrome for Android. On the native Android APK, system Bluetooth is used.'
        );
      } else {
        setScanError(
          isFa
            ? 'اسکن لغو شد یا دستگاهی انتخاب نشد.'
            : 'Bluetooth scan was cancelled or no device selected.'
        );
      }
    } finally {
      setIsScanning(false);
    }
  };

  const handleToggleLock = (deviceId: string) => {
    const updated = devices.map(d => ({
      ...d,
      isLocked: d.id === deviceId ? !d.isLocked : false,
    }));
    onUpdateDevices(updated);
    BluetoothService.saveDevices(updated);
    const target = updated.find(d => d.id === deviceId);
    if (target?.isLocked) {
      BluetoothService.setLockedDeviceId(deviceId);
      onAddLog({
        type: 'connect',
        title: isFa ? 'دستگاه مورد نظر قفل شد' : 'Device Locked to Keep-Alive',
        detail: isFa
          ? `پخش دائم سکوت مخصوص هندزفری ${target.name} قفل شد.`
          : `Non-stop carrier locked to ${target.name}.`,
        rssi: target.rssi,
        batteryLevel: target.batteryLevel,
      });
    } else {
      BluetoothService.setLockedDeviceId(null);
    }
  };

  const handleToggleConnect = (deviceId: string) => {
    const updated = devices.map(d => {
      if (d.id === deviceId) {
        const nextState = !d.connected;
        if (nextState) {
          onAddLog({
            type: 'connect',
            title: isFa ? 'اتصال مجدد هندزفری' : 'Headset Reconnected',
            detail: isFa
              ? `هندزفری ${d.name} با قدرت سیگنال ${d.rssi} dBm متصل شد.`
              : `${d.name} reconnected with RSSI ${d.rssi} dBm.`,
            rssi: d.rssi,
            batteryLevel: d.batteryLevel,
          });
        } else {
          onAddLog({
            type: 'disconnect',
            title: isFa ? 'قطع ارتباط هندزفری' : 'Headset Disconnected',
            detail: isFa
              ? `ارتباط ${d.name} قطع شد. دلیل: قطع دستی توسط کاربر.`
              : `${d.name} disconnected manually by user.`,
            rssi: -95,
            batteryLevel: d.batteryLevel,
            disconnectReason: isFa ? 'قطع دستی اتصال' : 'Manual Disconnect',
          });
        }
        return { ...d, connected: nextState };
      }
      return d;
    });
    onUpdateDevices(updated);
    BluetoothService.saveDevices(updated);
  };

  const getSignalStrength = (rssi: number) => {
    if (rssi >= -60) return { label: isFa ? 'عالی (فاصله نزدیک)' : 'Excellent', bars: 4, color: 'text-emerald-400' };
    if (rssi >= -75) return { label: isFa ? 'خوب (برد استاندارد)' : 'Good', bars: 3, color: 'text-cyan-400' };
    if (rssi >= -85) return { label: isFa ? 'متوسط (نزدیک افت)' : 'Fair', bars: 2, color: 'text-amber-400' };
    return { label: isFa ? 'بسیار ضعیف' : 'Weak', bars: 1, color: 'text-rose-400' };
  };

  const getBatteryColor = (level: number | null) => {
    if (level === null) return 'text-slate-400';
    if (level > 50) return 'text-emerald-400';
    if (level > 20) return 'text-amber-400';
    return 'text-rose-400';
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Top Header & Scan Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-white">
            {isFa ? 'مدیریت و نظارت بر هندزفری بلوتوث' : 'Bluetooth Headset Telemetry'}
          </h2>
          <p className="text-[11px] sm:text-xs text-slate-400">
            {isFa ? 'دستگاه قفل‌شده، قدرت سیگنال و درصد باتری' : 'Locked headset, signal strength & battery stats'}
          </p>
        </div>

        <button
          onClick={handleScanWebBluetooth}
          disabled={isScanning}
          className="flex items-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 px-3.5 py-2 text-xs font-semibold text-white transition-all active:scale-95 disabled:opacity-50 whitespace-nowrap self-stretch sm:self-auto justify-center"
        >
          {isScanning ? (
            <RefreshCw className="h-3.5 w-3.5 animate-spin text-cyan-400" />
          ) : (
            <Search className="h-3.5 w-3.5 text-cyan-400" />
          )}
          <span>
            {isScanning
              ? isFa ? 'در حال اسکن...' : 'Scanning...'
              : isFa ? 'اسکن بلوتوث جدید (BLE)' : 'Scan Device'}
          </span>
        </button>
      </div>

      {scanError && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-3 sm:p-4 text-xs text-amber-300 leading-relaxed">
          {scanError}
        </div>
      )}

      {/* Main Showcase Card for Current Locked Device */}
      {lockedDevice ? (
        <div className="rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 p-4 sm:p-6 shadow-xl relative overflow-hidden">
          <div className="relative z-10 space-y-4 sm:space-y-6">
            {/* Top row: Device identity & lock status */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="relative flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shrink-0">
                  <Bluetooth className="h-6 w-6 sm:h-7 sm:w-7" />
                  {lockedDevice.connected && (
                    <span className="absolute bottom-1 right-1 flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                    </span>
                  )}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h3 className="text-base sm:text-lg font-bold text-white truncate">
                      {lockedDevice.name}
                    </h3>
                    {lockedDevice.isLocked && (
                      <span className="flex items-center gap-1 rounded bg-cyan-500/10 border border-cyan-500/30 px-1.5 py-0.5 text-[10px] font-mono text-cyan-300">
                        <Lock className="h-2.5 w-2.5" />
                        <span>{isFa ? 'قفل‌شده' : 'Locked'}</span>
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                    <span className="font-mono text-slate-300">{lockedDevice.macAddress}</span>
                    <span>·</span>
                    <span className={lockedDevice.connected ? 'text-emerald-400 font-medium' : 'text-slate-500'}>
                      {lockedDevice.connected
                        ? isFa ? 'متصل و پایدار' : 'Connected'
                        : isFa ? 'قطع' : 'Disconnected'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  onClick={() => handleToggleLock(lockedDevice.id)}
                  className={`flex-1 sm:flex-initial flex items-center justify-center gap-1 px-3 py-2 rounded-xl text-xs font-medium border transition-colors ${
                    lockedDevice.isLocked
                      ? 'border-cyan-500/40 bg-cyan-950/40 text-cyan-300'
                      : 'border-slate-800 bg-slate-800 text-slate-300 hover:bg-slate-750'
                  }`}
                >
                  {lockedDevice.isLocked ? <Lock className="h-3 w-3" /> : <Unlock className="h-3 w-3" />}
                  <span>{lockedDevice.isLocked ? (isFa ? 'قفل است' : 'Locked') : (isFa ? 'قفل روی این دستگاه' : 'Lock')}</span>
                </button>

                <button
                  onClick={() => handleToggleConnect(lockedDevice.id)}
                  className={`flex-1 sm:flex-initial flex items-center justify-center px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                    lockedDevice.connected
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30'
                      : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                  }`}
                >
                  <span>{lockedDevice.connected ? (isFa ? 'قطع اتصال' : 'Disconnect') : (isFa ? 'اتصال مجدد' : 'Connect')}</span>
                </button>
              </div>
            </div>

            {/* 4 Metric Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 sm:gap-4">
              {/* Battery card */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 sm:p-4">
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                  <span>{isFa ? 'درصد باتری' : 'Battery'}</span>
                  <Battery className={`h-3.5 w-3.5 ${getBatteryColor(lockedDevice.batteryLevel)}`} />
                </div>
                <div className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-white">
                  {lockedDevice.batteryLevel !== null ? `${lockedDevice.batteryLevel}%` : '—'}
                </div>
                <div className="mt-2 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      (lockedDevice.batteryLevel ?? 0) > 50
                        ? 'bg-emerald-400'
                        : (lockedDevice.batteryLevel ?? 0) > 20
                        ? 'bg-amber-400'
                        : 'bg-rose-400'
                    }`}
                    style={{ width: `${lockedDevice.batteryLevel ?? 0}%` }}
                  />
                </div>
              </div>

              {/* RSSI Signal card */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 sm:p-4">
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                  <span>{isFa ? 'قدرت سیگنال' : 'Signal (RSSI)'}</span>
                  <Wifi className={`h-3.5 w-3.5 ${getSignalStrength(lockedDevice.rssi).color}`} />
                </div>
                <div className="flex items-baseline gap-1 text-xl sm:text-2xl font-bold font-mono text-white tabular-nums">
                  <span>{lockedDevice.rssi}</span>
                  <span className="text-[10px] text-slate-500 font-normal">dBm</span>
                </div>
                <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                  <span className="truncate">{getSignalStrength(lockedDevice.rssi).label}</span>
                  <div className="flex items-end gap-0.5 h-2.5">
                    {[1, 2, 3, 4].map(b => (
                      <div
                        key={b}
                        className={`w-1 rounded-sm ${
                          b <= getSignalStrength(lockedDevice.rssi).bars ? 'bg-cyan-400' : 'bg-slate-800'
                        }`}
                        style={{ height: `${b * 25}%` }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Prevented drops counter */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 sm:p-4">
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                  <span>{isFa ? 'کانال استریم' : 'Audio Link'}</span>
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                </div>
                <div className="text-base sm:text-lg font-bold font-mono text-emerald-400">
                  A2DP SINK
                </div>
                <p className="mt-2 text-[10px] text-slate-400 truncate">
                  {isFa ? 'استریم فعال ۲۴ ساعته' : 'Continuous Keep-Alive'}
                </p>
              </div>

              {/* Protocol status */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 sm:p-4">
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                  <span>{isFa ? 'کدک بلوتوث' : 'Codec'}</span>
                  <Radio className="h-3.5 w-3.5 text-cyan-400" />
                </div>
                <div className="text-base sm:text-lg font-bold font-mono text-white truncate">
                  SBC / AAC
                </div>
                <p className="mt-2 text-[10px] text-slate-400 truncate">
                  {isFa ? 'پخش پیوسته بدون وقفه' : 'Uninterrupted link'}
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Empty State when no device is paired yet */
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-8 text-center space-y-4">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-800 text-slate-400 border border-slate-700">
            <Headphones className="h-8 w-8 text-cyan-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {isFa ? 'هنوز دستگاهی متصل نشده است' : 'No Bluetooth Headset Connected'}
            </h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto leading-relaxed">
              {isFa
                ? 'بلوتوث هندزفری خود را روشن کنید و دکمه اسکن زیر را فشار دهید تا به برنامه متصل شده و قفل شود.'
                : 'Turn on your Bluetooth headset and click the button below to scan and lock it.'}
            </p>
          </div>
          <button
            onClick={handleScanWebBluetooth}
            disabled={isScanning}
            className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs inline-flex items-center gap-2 transition-all active:scale-95"
          >
            <Search className="h-4 w-4" />
            <span>{isFa ? 'جستجو و اسکن هندزفری' : 'Scan for Headset'}</span>
          </button>
        </div>
      )}

      {/* Paired Devices List */}
      {devices.length > 0 && (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 sm:p-6 space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white">
                {isFa ? 'تاریخچه دستگاه‌های ثبت‌شده' : 'Device History'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {isFa ? 'لیست هندزفری‌های جفت‌شده با این سیستم' : 'List of previously paired Bluetooth devices'}
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500">
              {devices.length} {isFa ? 'دستگاه' : 'Devices'}
            </span>
          </div>

          <div className="divide-y divide-slate-800/80">
            {devices.map(device => {
              const isCurrent = device.id === lockedDevice?.id;
              return (
                <div
                  key={device.id}
                  className={`py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 transition-colors ${
                    isCurrent ? 'bg-cyan-950/10 -mx-2 px-2 rounded-xl' : 'hover:bg-slate-850/40 -mx-2 px-2 rounded-xl'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className={`h-9 w-9 rounded-xl flex items-center justify-center border shrink-0 ${
                      device.connected
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}>
                      <Bluetooth className="h-4 w-4" />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs sm:text-sm font-semibold text-white truncate">
                          {device.name}
                        </span>
                        {device.isLocked && (
                          <span className="text-[9px] font-mono bg-cyan-500/20 text-cyan-300 px-1 py-0.5 rounded border border-cyan-500/30">
                            {isFa ? 'قفل فعلی' : 'Locked'}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                        <span className="font-mono">{device.macAddress}</span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-2.5 w-2.5 text-slate-500" />
                          <span>{device.lastSeen}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <div className="flex items-center gap-1 text-[11px] font-mono text-slate-300">
                      <BatteryCharging className="h-3 w-3 text-cyan-400" />
                      <span>{device.batteryLevel !== null ? `${device.batteryLevel}%` : '—'}</span>
                    </div>

                    <button
                      onClick={() => handleToggleLock(device.id)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors ${
                        device.isLocked
                          ? 'border-cyan-500/50 bg-cyan-500/20 text-cyan-300'
                          : 'border-slate-700 hover:border-slate-600 bg-slate-800 text-slate-300'
                      }`}
                    >
                      {device.isLocked ? (isFa ? 'قفل است' : 'Locked') : (isFa ? 'قفل' : 'Lock')}
                    </button>

                    <button
                      onClick={() => handleToggleConnect(device.id)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                        device.connected
                          ? 'text-rose-400 hover:text-rose-300 bg-rose-950/20'
                          : 'text-emerald-400 hover:text-emerald-300 bg-emerald-950/20'
                      }`}
                    >
                      {device.connected ? (isFa ? 'قطع' : 'Disconnect') : (isFa ? 'اتصال' : 'Connect')}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
