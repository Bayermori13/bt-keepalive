import React from 'react';
import { Bluetooth, Globe, Code2 } from 'lucide-react';
import { Language } from '../types';
import { MzLogo } from './MzLogo';

interface HeaderProps {
  language: Language;
  onToggleLanguage: () => void;
  onOpenProjectModal: () => void;
  activeSection: string;
  onSelectSection: (section: string) => void;
  isServiceActive: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onToggleLanguage,
  onOpenProjectModal,
  activeSection,
  onSelectSection,
  isServiceActive,
}) => {
  const isFa = language === 'fa';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/95 backdrop-blur-md">
      <div className="mx-auto flex h-14 sm:h-16 max-w-7xl items-center justify-between gap-4 px-3 sm:px-6 lg:px-8">
        {/* Zone 1: Clean Brand Wordmark & Official MZ Logo */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          <MzLogo size={34} />
          <div className="flex flex-col">
            <span className="text-sm sm:text-base font-bold tracking-tight text-white whitespace-nowrap flex items-center gap-1.5">
              <span className="font-mono text-cyan-400 font-extrabold">MZ</span>
              <span>{isFa ? 'هندزفری StayAlive' : 'StayAlive'}</span>
            </span>
          </div>
        </div>

        {/* Zone 2: Desktop 3 Core Tabs (Removed GitHub from top navigation as requested) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            onClick={() => onSelectSection('controller')}
            className={`whitespace-nowrap transition-colors hover:text-white py-1 ${
              activeSection === 'controller' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            {isFa ? 'کنترلر و پخش سکوت' : 'Keep-Alive Engine'}
          </button>
          <button
            onClick={() => onSelectSection('devices')}
            className={`whitespace-nowrap transition-colors hover:text-white py-1 ${
              activeSection === 'devices' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            {isFa ? 'مدیریت دستگاه و باتری' : 'Device & Signal'}
          </button>
          <button
            onClick={() => onSelectSection('history')}
            className={`whitespace-nowrap transition-colors hover:text-white py-1 ${
              activeSection === 'history' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            {isFa ? 'لاگ‌ها و رویدادها' : 'Activity & Telemetry'}
          </button>
        </nav>

        {/* Zone 3: Compact Mobile-Friendly Controls (No overflowing button) */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Active status indicator badge */}
          <div className={`hidden xs:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono border ${
            isServiceActive
              ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/30'
              : 'bg-slate-900 text-slate-500 border-slate-800'
          }`}>
            <span className={`h-1.5 w-1.5 rounded-full ${isServiceActive ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`} />
            <span>{isServiceActive ? (isFa ? 'سکوت دائم' : 'Non-Stop') : (isFa ? 'خاموش' : 'Standby')}</span>
          </div>

          {/* Android Project / GitHub Access Trigger (Compact Icon Button) */}
          <button
            onClick={onOpenProjectModal}
            className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 hover:bg-slate-850 px-2.5 py-1.5 text-xs text-slate-300 hover:text-white transition-colors"
            title={isFa ? 'پروژه اندروید و بیلد APK در گیت‌هاب' : 'Android Studio & GitHub Build'}
          >
            <Code2 className="h-3.5 w-3.5 text-cyan-400" />
            <span className="hidden sm:inline font-mono">{isFa ? 'پروژه APK' : 'APK Code'}</span>
          </button>

          {/* Language toggle */}
          <button
            onClick={onToggleLanguage}
            className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2 py-1.5 text-xs font-mono text-slate-300 hover:bg-slate-800 transition-colors"
            title={isFa ? 'Switch to English' : 'تغییر زبان به فارسی'}
          >
            <Globe className="h-3 w-3 text-cyan-400" />
            <span>{isFa ? 'EN' : 'فا'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
