/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { KeepAliveController } from './components/KeepAliveController';
import { DeviceManager } from './components/DeviceManager';
import { ActivityLog } from './components/ActivityLog';
import { GitHubBuildGuide } from './components/GitHubBuildGuide';
import { BluetoothDeviceInfo, ActivityEvent, Language } from './types';
import { BluetoothService } from './utils/bluetoothService';
import { generateAndDownloadProjectZip } from './utils/zipExporter';
import { audioEngine } from './utils/audioEngine';
import {
  Volume2,
  Bluetooth,
  Activity,
  ShieldCheck,
  X,
  Code2,
} from 'lucide-react';

const STORAGE_KEY_EVENTS = 'bt_stayalive_events_history';

export default function App() {
  const [language, setLanguage] = useState<Language>('fa');
  const [activeSection, setActiveSection] = useState<'controller' | 'devices' | 'history'>('controller');
  const [isProjectModalOpen, setIsProjectModalOpen] = useState<boolean>(false);
  const [isServiceActive, setIsServiceActive] = useState<boolean>(true);
  const [devices, setDevices] = useState<BluetoothDeviceInfo[]>([]);
  const [isDownloadingZip, setIsDownloadingZip] = useState<boolean>(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [events, setEvents] = useState<ActivityEvent[]>([]);

  // Load real saved devices & saved events on initial mount
  useEffect(() => {
    const loadedDevices = BluetoothService.getSavedDevices();
    setDevices(loadedDevices);

    try {
      const savedEvents = localStorage.getItem(STORAGE_KEY_EVENTS);
      if (savedEvents) {
        setEvents(JSON.parse(savedEvents));
      }
    } catch {
      // Storage error
    }

    // Start production background audio stream
    audioEngine.start('pure_silence');
  }, []);

  // Update HTML direction and language
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'fa' ? 'rtl' : 'ltr';
  }, [language]);

  const isFa = language === 'fa';

  const handleToggleLanguage = () => {
    setLanguage(prev => (prev === 'fa' ? 'en' : 'fa'));
  };

  const handleToggleService = () => {
    if (isServiceActive) {
      audioEngine.stop();
      setIsServiceActive(false);
      handleAddLog({
        type: 'keepalive',
        title: isFa ? 'سرویس سکوت دائم خاموش شد' : 'Continuous Silence Stopped',
        detail: isFa
          ? 'استریم صوتی پس‌زمینه متوقف شد.'
          : 'Background keep-alive stream stopped.',
      });
    } else {
      audioEngine.start('pure_silence');
      setIsServiceActive(true);
      handleAddLog({
        type: 'keepalive',
        title: isFa ? 'سرویس سکوت دائم روشن شد' : 'Continuous Silence Started',
        detail: isFa
          ? 'پخش پیوسته بافر صفر دیجیتال (PCM 0dB) برای بیدار نگه‌داشتن هندزفری فعال است.'
          : 'Non-stop zero PCM carrier active.',
      });
    }
  };

  const handleAddLog = (eventData: Omit<ActivityEvent, 'id' | 'timestamp'>) => {
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
    const newEvent: ActivityEvent = {
      id: `ev-${Date.now()}-${Math.random()}`,
      timestamp: timeStr,
      ...eventData,
    };
    setEvents(prev => {
      const updated = [newEvent, ...prev.slice(0, 99)];
      try {
        localStorage.setItem(STORAGE_KEY_EVENTS, JSON.stringify(updated));
      } catch {
        // Storage full
      }
      return updated;
    });
  };

  const handleClearLogs = () => {
    setEvents([]);
    try {
      localStorage.removeItem(STORAGE_KEY_EVENTS);
    } catch {
      // Cleaned
    }
  };

  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    try {
      await generateAndDownloadProjectZip();
      setNotification(
        isFa
          ? 'پروژه کامل اندروید با موفقیت در قالب فایل ZIP دانلود شد!'
          : 'Android project ZIP successfully downloaded!'
      );
      setTimeout(() => setNotification(null), 4000);
    } catch {
      setNotification(
        isFa ? 'خطا در ایجاد فایل ZIP پروژه.' : 'Error generating project ZIP.'
      );
      setTimeout(() => setNotification(null), 4000);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500/20 selection:text-cyan-300">
      {/* Top Navigation Bar: Mobile Responsive & Clean */}
      <Header
        language={language}
        onToggleLanguage={handleToggleLanguage}
        onOpenProjectModal={() => setIsProjectModalOpen(true)}
        activeSection={activeSection}
        onSelectSection={(sec) => setActiveSection(sec as 'controller' | 'devices' | 'history')}
        isServiceActive={isServiceActive}
      />

      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-20 sm:bottom-6 left-1/2 -translate-x-1/2 z-50 rounded-xl bg-cyan-500 text-slate-950 font-bold px-4 py-2.5 text-xs shadow-2xl shadow-cyan-500/30 flex items-center gap-2 border border-cyan-400">
          <ShieldCheck className="h-4 w-4" />
          <span>{notification}</span>
        </div>
      )}

      {/* Main Content Viewport */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-3 sm:px-6 lg:px-8 py-4 sm:py-6 space-y-4 sm:space-y-6 pb-24 md:pb-12">
        {/* Navigation Tabs Bar (Desktop and Tablet): Exactly 3 Core Tabs */}
        <div className="hidden md:flex items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveSection('controller')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium transition-all ${
                activeSection === 'controller'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Volume2 className="h-4 w-4" />
              <span>{isFa ? 'کنترلر پخش سکوت دائم' : 'Non-Stop Engine'}</span>
            </button>

            <button
              onClick={() => setActiveSection('devices')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium transition-all ${
                activeSection === 'devices'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Bluetooth className="h-4 w-4" />
              <span>{isFa ? 'دستگاه و قدرت سیگنال' : 'Device & Signal'}</span>
            </button>

            <button
              onClick={() => setActiveSection('history')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium transition-all ${
                activeSection === 'history'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Activity className="h-4 w-4" />
              <span>{isFa ? 'لاگ‌ها و دلایل قطعی' : 'Activity & Drops'}</span>
            </button>
          </div>

          {/* Quick trigger for Android Studio / GitHub project */}
          <button
            onClick={() => setIsProjectModalOpen(true)}
            className="flex items-center gap-1.5 text-xs font-mono text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            <Code2 className="h-3.5 w-3.5" />
            <span>{isFa ? 'پروژه کامل اندروید و بیلد APK در گیت‌هاب' : 'Android Studio & GitHub APK Guide'}</span>
          </button>
        </div>

        {/* Dynamic Section Render */}
        {activeSection === 'controller' && (
          <KeepAliveController
            language={language}
            onAddLog={handleAddLog}
            isActive={isServiceActive}
            onToggleActive={handleToggleService}
          />
        )}

        {activeSection === 'devices' && (
          <DeviceManager
            language={language}
            devices={devices}
            onUpdateDevices={setDevices}
            onAddLog={handleAddLog}
          />
        )}

        {activeSection === 'history' && (
          <ActivityLog
            language={language}
            events={events}
            onClearLogs={handleClearLogs}
            onAddLog={handleAddLog}
          />
        )}
      </main>

      {/* GitHub & Android Studio Export Modal */}
      {isProjectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-3xl border border-slate-750 bg-slate-900 p-4 sm:p-6 shadow-2xl">
            <button
              onClick={() => setIsProjectModalOpen(false)}
              className="absolute top-4 left-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>

            <GitHubBuildGuide
              language={language}
              onDownloadZip={handleDownloadZip}
              isDownloadingZip={isDownloadingZip}
              onClose={() => setIsProjectModalOpen(false)}
            />
          </div>
        </div>
      )}

      {/* Mobile Fixed Bottom Navigation Bar: Exactly 3 Core Tabs */}
      <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden border-t border-slate-800/90 bg-slate-950/95 backdrop-blur-md px-2 py-1.5 safe-bottom">
        <div className="grid grid-cols-3 items-center">
          <button
            onClick={() => setActiveSection('controller')}
            className={`flex flex-col items-center justify-center py-1.5 transition-colors ${
              activeSection === 'controller' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Volume2 className="h-5 w-5" />
            <span className="text-[11px] mt-1">{isFa ? 'کنترلر' : 'Engine'}</span>
          </button>

          <button
            onClick={() => setActiveSection('devices')}
            className={`flex flex-col items-center justify-center py-1.5 transition-colors ${
              activeSection === 'devices' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bluetooth className="h-5 w-5" />
            <span className="text-[11px] mt-1">{isFa ? 'هندزفری' : 'Device'}</span>
          </button>

          <button
            onClick={() => setActiveSection('history')}
            className={`flex flex-col items-center justify-center py-1.5 transition-colors ${
              activeSection === 'history' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="h-5 w-5" />
            <span className="text-[11px] mt-1">{isFa ? 'لاگ‌ها' : 'Logs'}</span>
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 sm:py-6 text-center text-xs text-slate-500">
        <div className="mx-auto max-w-7xl px-4 flex flex-col sm:flex-row items-center justify-between gap-2 sm:gap-4">
          <p className="text-[11px] sm:text-xs">
            {isFa
              ? 'Bluetooth StayAlive - پخش دائم سکوت بدون وقفه و بدون تداخل در تماس و موزیک'
              : 'Bluetooth StayAlive - 24/7 Silent Carrier Headset Keep-Alive'}
          </p>
          <button
            onClick={() => setIsProjectModalOpen(true)}
            className="font-mono text-[11px] text-cyan-400/80 hover:text-cyan-300 transition-colors underline"
          >
            {isFa ? 'دانلود سورس اندروید و دستورات گیت‌هاب' : 'Download Android Source & GitHub Setup'}
          </button>
        </div>
      </footer>
    </div>
  );
}
